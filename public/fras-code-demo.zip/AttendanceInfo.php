<?php
/**
 * Created by PhpStorm.
 * User: iqtikve
 * Date: 21.10.18
 * Time: 17:54
 */

namespace App\Entity;


use Nette\Utils\DateTime;

class AttendanceInfo {
    /** @var User $user */
    private $user;

    /** @var int $month */
    private $month;

    /** @var int $year */
    private $year;

    /** @var Attendance[] $attendance */
    private $attendance;

    /** @var Holiday[] $holiday */
    private $holiday;

    /** @var array $public_holiday */
    private $public_holiday;

    /** @var array $parameters */
    private $parameters;

    /**
     * AttendanceInfo constructor.
     * @param User $user
     * @param int $month
     * @param int $year
     * @param Attendance[] $attendance
     * @param Holiday[] $holiday
     * @param array $public_holiday
     * @param array $parameters
     */
    public function __construct(User $user, $month, $year, array $attendance, array $holiday, array $public_holiday, array $parameters) {
        $this->user = $user;
        $this->month = $month;
        $this->year = $year;
        $this->attendance = $attendance;
        $this->holiday = $holiday;
        $this->public_holiday = $public_holiday;
        $this->parameters = $parameters;
    }

    /**
     * @return float|int
     */
    public function getWorkedHoursSum() {
        $sum = 0;
        foreach ($this->attendance as $a) {
            $sum += $a->getLength();
        }
        return $sum;
    }

    /**
     * @return int
     */
    public function getWorkedDays() {
        return count($this->attendance);
    }

    /**
     * @return float|int
     */
    public function getUsedHolidayHoursSum() {
        $sum = 0;
        foreach ($this->holiday as $h) {
            if ($h->isApproved()) $sum += $h->getLength();
        }
        return $sum;
    }

    /**
     * @return float|int
     */
    public function getUserHoursPerDay() {
        return $this->user->getHoursPerWeek() / 5;
    }

    /**
     * @return float|int
     */
    public function getUsedHolidayDays() {
        return $this->getUserHoursPerDay() == 0 ? 0 : $this->getUsedHolidayHoursSum() / $this->getUserHoursPerDay();
    }

    /**
     * @return float|int
     */
    public function getPublicHolidayHours() {
        if (!$this->parameters['pay_public_holidays']['value']) return 0;

        $days = 0;
        foreach ($this->public_holiday as $day_str => $name) {
            $day = DateTime::from($day_str);
            if ($this->month == $day->format('n') && $this->year == $day->format('Y') && $day->format('N') <= 5) {
                $days++;
            }
        }
        return $days * $this->getUserHoursPerDay();
    }

    /**
     * @return float|int
     */
    public function getSalary() {
        return ($this->getWorkedHoursSum() + $this->getUsedHolidayHoursSum() + $this->getPublicHolidayHours()) * $this->user->getHourSalary();
    }

    /**
     * @return float
     */
    public function getSuperTaxedSalary() {
        return round($this->getSalary() * (1 + 0.09 + 0.25), -2);
    }

    /**
     * @return bool
     */
    public function isNetSalaryShowable() {
        return in_array($this->user->getContractType()->getCode(), ['hpp', 'dpp', 'dpc']) && $this->parameters['show_net_salary']['value'];
    }

    /**
     * @return float|int
     */
    public function getTaxWithoutDiscounts() {
        if ($this->isNetSalaryShowable()) {
            return $this->getSuperTaxedSalary() * ($this->parameters['tax_percent']['value'] / 100);
        }

        return 0;
    }

    /**
     * @return int
     */
    public function getTaxDiscount() {
        // TODO příjemci invalidního důchodu prvního stupně a druhého stupně na daňovou slevu ve výši 210 Kč a příjemci invalidního důchodu třetího stupně na daňovou slevu ve výši 420 Kč, na průkaz ZTP/P náleží daňová sleva 1 345 Kč
        // TODO Vždy jeden z rodičů může uplatnit daňové zvýhodnění na děti. Na první dítě bude v roce 2018 činit 1 267 Kč (o 150 Kč více než v roce 2017), na druhé dítě 1 617 Kč a na třetí a další dítě potom 2 017 Kč
        if (!$this->user->isTaxDeclarationSigned()) {
            return 0;
        } else {
            if ($this->user->isStudent()) {
                return $this->parameters['taxpayer_discount']['value'] + $this->parameters['student_discount']['value'];
            } else {
                return $this->parameters['taxpayer_discount']['value'];
            }
        }
    }

    /**
     * @return mixed
     */
    public function getTax() {
        return max($this->getTaxWithoutDiscounts() - $this->getTaxDiscount(), 0);
    }

    /**
     * @return float|int|mixed
     */
    public function getHealthInsuranceTax() {
        if ($this->user->getContractType()->getCode() == 'dpp' && $this->getSalary() > $this->parameters['max_salary_dpp']['value']
                || $this->user->getContractType()->getCode() == 'dpc' && $this->getSalary() > $this->parameters['max_salary_dpc']['value']
                || $this->user->getContractType()->getCode() == 'hpp') {
            if ($this->user->isStatePolicyholder()) {
                return $this->getSalary() * ($this->parameters['percent_health_insurance']['value'] / 100);
            } else {
                return max($this->getSalary() * ($this->parameters['percent_health_insurance']['value'] / 100), $this->parameters['min_month_health_insurance']['value']);
            }
        }

        return 0;
    }

    /**
     * @return float|int
     */
    public function getSocialInsuranceTax() {
        if ($this->user->getContractType()->getCode() == 'dpp' && $this->getSalary() > $this->parameters['max_salary_dpp']['value']
            || $this->user->getContractType()->getCode() == 'dpc' && $this->getSalary() > $this->parameters['max_salary_dpc']['value']
            || $this->user->getContractType()->getCode() == 'hpp') {
            return $this->getSalary() * ($this->parameters['percent_social_insurance']['value'] / 100);
        }

        return 0;
    }

    /**
     * @return float|int|mixed
     */
    public function getNetSalary() {
        return $this->getSalary() - $this->getTax() - $this->getHealthInsuranceTax() - $this->getSocialInsuranceTax();
    }

    /**
     * @return Day[];
     */
    public function getCalendar() {
        $calendar = [];

        // 1. PublicHoliday
        if ($this->parameters['public_holidays_on']['value']) {
            foreach ($this->public_holiday as $day_str => $name) {
                $day = DateTime::from($day_str);
                if ($this->month == $day->format('n') && $this->year == $day->format('Y')) {
                    $calendar[$day_str] = new DayPublicHoliday($day, $name);
                }
            }
        }

        // 2. Holiday
        foreach ($this->holiday as $h) {
            if ($h->isApproved()) {
                foreach ($h->getDateRange() as $day) {
                    if (isset($calendar[$day->format('Y-m-d')])) continue;
                    $calendar[$day->format('Y-m-d')] = new DayHoliday($day, $h->getHolidayHoursPerDay());
                }
            }
        }

        // 3. Attendance
        foreach ($this->attendance as $a) {
            $day = DateTime::from($a->getDate());
            if (isset($calendar[$day->format('Y-m-d')])) continue;
            $calendar[$day->format('Y-m-d')] = new DayAttendance($day, DateTime::from($a->getFrom()), DateTime::from($a->getTo()), $a->getLength(), $a->getId());
        }

        // 4. Empty days
        $first = DateTime::from(date("01-$this->month-$this->year"));
        $last = DateTime::from(date("01-$this->month-$this->year"))->modify('+1 month, -1 day');
        for ($day = $first; $day <= $last; $day->modify('+1 day')) {
            if (isset($calendar[$day->format('Y-m-d')])) continue;
            $calendar[$day->format('Y-m-d')] = new Day($day->modifyClone());
        }

        ksort($calendar);
        return $calendar;
    }
}