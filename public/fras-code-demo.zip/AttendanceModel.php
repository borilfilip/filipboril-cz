<?php
/**
 * Created by PhpStorm.
 * User: iqtikve
 * Date: 9.10.18
 * Time: 8:38
 */

namespace App\Models;


use App\Entity\Attendance;
use App\Entity\AttendanceDetail;
use App\Entity\AttendanceInfo;
use App\Entity\User;
use app\Exceptions\NullParameterException;
use Kdyby\Doctrine\EntityManager;
use Kdyby\Translation\Translator;
use Nette\Database\Context;
use Nette\Utils\DateTime;

class AttendanceModel extends BaseModel {
    /** @var HolidayModel $holidayModel */
    private $holidayModel;

    /** @var ParameterModel $parameterModel */
    private $parameterModel;

    /** @var Translator $translator */
    private $translator;

    /**
     * AttendanceModel constructor.
     * @param Context $db
     * @param EntityManager $entityManager
     * @param Translator $translator
     * @param HolidayModel $holidayModel
     * @param ParameterModel $parameterModel
     */
    public function __construct(Context $db, EntityManager $entityManager, Translator $translator, HolidayModel $holidayModel, ParameterModel $parameterModel) {
        parent::__construct($db, $entityManager);
        $this->translator = $translator;
        $this->holidayModel = $holidayModel;
        $this->parameterModel = $parameterModel;
    }

    /**
     * @param int $id
     * @return Attendance|object
     */
    public function getAttendance($id) {
        return $this->entityManager->getRepository(Attendance::class)->find($id);
    }

    /**
     * @return Attendance[]
     */
    public function getAllAttendances() {
        return $this->entityManager->getRepository(Attendance::class)->findAll();
    }

    /**
     * @param User $user
     * @param $month
     * @param $year
     * @return Attendance[]
     */
    public function getAttendanceByMonthAndYear(User $user, $month, $year) {
        $first = DateTime::from("$year-$month-01");
        $last = DateTime::from("$year-$month-01")->modify('last day of this month');

        return $this->entityManager->createQueryBuilder()
            ->select('a')
            ->from(Attendance::class, 'a')
            ->where('a.date BETWEEN :start AND :end AND a.user = :user')
            ->setParameter('start', $first->format('Y-m-d'))
            ->setParameter('end', $last->format('Y-m-d'))
            ->setParameter('user', $user)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param Attendance $attendance
     * @throws \Exception
     */
    public function saveAttendance(Attendance $attendance) {
        $this->entityManager->persist($attendance);
        $this->entityManager->flush();
    }

    /**
     * @param Attendance $attendance
     * @throws \Exception
     */
    public function deleteAttendance(Attendance $attendance) {
        $this->entityManager->remove($attendance);
        $this->entityManager->flush();
    }

    /**
     *
     */
    public function computeAttendance() {
        $this->db->query("insert into attendance (user_id, date, from_time, to_time, length)
                              select user_id, date, from_time, to_time, length
                              from v_attendance
                              where date < CURDATE()
                                and (date > (select max(date) from attendance) or (select count(*) from attendance) = 0)");
    }

    /**
     * @param User $user
     * @param int $limit
     * @return array|\Nette\Database\Table\IRow[]|\Nette\Database\Table\Selection
     */
    public function getLastAttendance(User $user, $limit = 1) {
        return $this->db->table('attendance')
            ->select('*')
            ->where('user_id = ?', $user->getId())
            ->order('date DESC')
            ->limit($limit)
            ->fetchAll();
    }

    /**
     * @param User $user
     * @param \DateTime $date
     * @return array
     */
    public function getAttendanceDetails(User $user, \DateTime $date) {
        return $this->entityManager->getRepository(AttendanceDetail::class)->findBy(['user' => $user, 'date' => $date]);
    }

    /**
     * @return mixed
     */
    public function getReclamationsToCheckCount() {
        return $this->db->table('reclamation')->select('count(*) AS cnt')->where('approved IS NULL')->fetch()['cnt'];
    }

    /**
     * @param User $user
     * @param int $month
     * @param int $year
     * @return AttendanceInfo
     * @throws NullParameterException
     */
    public function getAttendanceInfo(User $user, $month, $year) {
        if (is_null($user) || is_null($month) || is_null($year)) throw new NullParameterException("User, month or year is null");

        $attendance = $this->getAttendanceByMonthAndYear($user, $month, $year);
        $holiday = $this->holidayModel->getUserHoliday($user, $year, $month);
        $public_holidays = $this->holidayModel->getPublicHolidays($year);
        $parameters = $this->parameterModel->getParameters();

        return new AttendanceInfo($user, $month, $year, $attendance, $holiday, $public_holidays, $parameters);
    }

    /**
     * @param array|null $filters
     * @param array|null $order
     * @return \Nette\Database\Table\Selection
     */
    public function getAttendanceList($filters = null, $order = null) {
        $selection = $this->db->table('v_attendance_grid')
            ->select('*');

        if (!is_null($filters)) {
            $selection->where($filters);
        }

        if (isset($order[0])) {
            $selection->order(implode(' ', $order));
        }

        return $selection;
    }

    /**
     * @param null $filters
     * @return \Nette\Database\Table\Selection
     */
    public function getAttendanceLengthList($filters = null) {
        $selection = $this->db->table('v_attendance_grid')
            ->select('user, SUM(length) AS length')
            ->group('user');

        if (!is_null($filters)) {
            $selection->where($filters);
        }

        return $selection;
    }

    /**
     * @return array
     */
    public function getAttendanceChartDataByUsers() {
        return $this->db->table('attendance')
            ->select('CONCAT(firstname, \' \', surname) AS name, ROUND(SUM(length), 2) AS length')
            ->joinWhere('user', 'attendance.user_id = user.id')
            ->where('YEAR(date) = ?', date('Y'))
            ->group('user.id')
            ->order('length DESC')
            ->fetchPairs('name', 'length');
    }

    /**
     * @return array
     */
    public function getAttendanceChartDataByMonths() {
        $data = $this->db->query('select *
            from (
                select y, m, month, ifnull(round(sum(length), 2), 0) as length
                    from z_months
                    left join attendance on (year(date) = y and month(date) = m)
                    where CONCAT(y, \'-\', LPAD(m, 2, \'0\'), \'-01\') < NOW()
                    group by y, m, month
                    order by y desc, m desc
                    limit 6
            ) x
            order by y asc, m asc')->fetchPairs('month', 'length');

        $translated = [];
        foreach ($data as $month => $value) {
            $translated[$this->translator->trans($month)] = $value;
        }

        return $translated;
    }

    /**
     * @return array
     */
    public function getAttendanceChartDataByHours() {
        return $this->db->query('select h, count(id) AS length
            from z_hours
            left join attendance on h between hour(from_time) and hour(to_time)
            group by h')->fetchPairs('h', 'length');
    }
}