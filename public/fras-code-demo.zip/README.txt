Project: Face recognition attendance system
Author: Bc. Filip Bořil
Email: borilfilip@gmail.com
Web: http://filipboril.cz

Information about project is located at http://filipboril.cz/#/projects

In this demo, there are 2 php classes:
 - AttendanceModel.php - class (model) which uses ORM (Doctrine) to load Attendance entity from database; it uses built-in methods and also query builder and manual SQL queries
 - AttendanceInfo.php - class (entity) which is used compute user's attendance details; it is created by AttendanceModel and is used in presenters and templates
