import React, { useContext, useEffect, useState } from "react";
import { Alert, StyleSheet, View } from "react-native";
import { Button, Text, withTheme } from "react-native-elements";
import { BarCodeScanner } from "expo-barcode-scanner";
import { useNavigation } from "@react-navigation/native";
import QRCode from "react-native-qrcode-svg";

import ComponentAtBottom from "../../components/ComponentAtBottom";
import NextButton from "../../components/NextButton";
import UserContext from "../../contexts/UserContext";
import { pairPartner } from "../../helpers/partnerHelper";
import Icon from "../../components/Icon";

function QRScreen(props) {
  const [scanning, setScanning] = useState(false);
  const [hasPermission, setHasPermission] = useState(null);
  const userContext = useContext(UserContext);
  const navigation = useNavigation();
  const { user, myKey, partner, decryptPartnerWorks } = userContext;
  const { theme } = props;

  const QRValue = myKey && JSON.stringify({ UID: user.uid, key: myKey });

  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === "granted");
    })();
  });

  const handleBarCodeScanned = ({ data }) => {
    setScanning(false);
    try {
      const { UID, key } = JSON.parse(data);
      pairPartner(UID, key, userContext);
    } catch (_) {
      Alert.alert(
        "Nepodařilo se přečíst potřebná data",
        "Zkuste to znovu a pokud to ani poté nepůjde, zvolte možnost Nastavit ručně.",
        [
          {
            text: "OK",
          },
        ]
      );
    }
  };

  const isPartnerSet = partner?.email && partner?.uid;
  const partnerAndHisKeySet = isPartnerSet && decryptPartnerWorks;

  const nextButton = (
    <NextButton canContinue={partnerAndHisKeySet && myKey} route="Finish" />
  );

  return scanning && hasPermission ? (
    <View style={styles.scannerContainer}>
      <BarCodeScanner
        onBarCodeScanned={scanning ? handleBarCodeScanned : undefined}
        barCodeTypes={[BarCodeScanner.Constants.BarCodeType.qr]}
        style={StyleSheet.absoluteFillObject}
      />
      <Button
        title="Zavřít"
        onPress={() => setScanning(false)}
        buttonStyle={styles.closeScannerButton}
        containerStyle={styles.closeScannerButtonContainer}
      />
    </View>
  ) : (
    <ComponentAtBottom component={nextButton}>
      <Text h2 style={styles.firstHeadline}>
        Rychlé propojení s&nbsp;partnerem
      </Text>
      <Text>
        Pro rychlé propojení s vaším partnerem načtěte jeho QR kód a nechte
        partnera načíst ten váš. Pokud se vám to z nějakého důvodu nedaří nebo
        se chcete dovědět více o šifrování, zvolte možnost nastavit ručně.
      </Text>
      {QRValue && (
        <View style={styles.QRCodeContainer}>
          <QRCode value={QRValue} size={200} />
        </View>
      )}
      {partnerAndHisKeySet && (
        <View style={styles.partnerSetContainer}>
          <Text>Partner nastaven: {partner.email}</Text>
        </View>
      )}
      <Button
        title="Naskenovat QR kód partnera"
        type={partnerAndHisKeySet ? "outline" : "solid"}
        icon={
          <Icon
            name={partnerAndHisKeySet ? "checkbox-outline" : "stop-outline"}
            color={partnerAndHisKeySet ? theme.colors.primary : "white"}
          />
        }
        onPress={() => setScanning(true)}
        disabled={!hasPermission}
        containerStyle={styles.optionButtonContainer}
      />
      <Button
        title="Nastavit ručně"
        type="outline"
        icon={<Icon name="build-outline" color={theme.colors.primary} />}
        onPress={() => navigation.navigate("Partner")}
        containerStyle={styles.optionButtonContainer}
      />
    </ComponentAtBottom>
  );
}

const styles = StyleSheet.create({
  scannerContainer: { flex: 1, justifyContent: "flex-end" },
  closeScannerButton: {
    backgroundColor: "rgba(0,0,0,0.7)",
    paddingBottom: 15,
    borderRadius: 0,
  },
  closeScannerButtonContainer: { borderRadius: 0 },
  firstHeadline: { marginBottom: 10 },
  QRCodeContainer: {
    marginVertical: 30,
    flexDirection: "row",
    justifyContent: "center",
  },
  optionButtonContainer: { marginBottom: 10 },
  partnerSetContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 30,
  },
});

export default withTheme(QRScreen);
