import React, { useContext } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import AppNavigator from "./AppNavigator";
import SetupNavigator from "./SetupNavigator";
import UserContext from "../contexts/UserContext";
import ReAuthScreen from "../screens/settings/ReAuthScreen";
import KeyboardAvoidingView from "../components/KeyboardAvoidingView";

const Stack = createStackNavigator();

export default function RootNavigator() {
  const {
    decryptMeWorks,
    decryptPartnerWorks,
    passwordRequired,
    setup: { setupStarted },
  } = useContext(UserContext);

  const everythingSet = !setupStarted && decryptMeWorks && decryptPartnerWorks;

  return (
    <NavigationContainer>
      <KeyboardAvoidingView>
        <Stack.Navigator>
          {!everythingSet ? (
            <Stack.Screen
              name="Setup"
              component={SetupNavigator}
              options={{ headerShown: false }}
            />
          ) : passwordRequired ? (
            <Stack.Screen
              name="ReAuth"
              component={ReAuthScreen}
              options={{ title: "Zadejte heslo" }}
            />
          ) : (
            <Stack.Screen
              name="App"
              component={AppNavigator}
              options={{ headerShown: false }}
            />
          )}
        </Stack.Navigator>
      </KeyboardAvoidingView>
    </NavigationContainer>
  );
}
